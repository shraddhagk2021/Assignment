package com.form.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.form.model.AppointmentModel;
import com.form.repository.PatientRepository;
import com.form.service.AppointmentService;

@Controller
public class AppointmentController {
	
    //@Autowired
	//AppointmentService appService;
	
	@Autowired
	PatientRepository  repo;
	
//	@RequestMapping(value = "/index", method = RequestMethod.GET)
//	  public String showForm(Model model) {
//	    model.addAttribute("registration", new AppointmentService());
//	    return "index";
//	  }
	
	@GetMapping("/")
	//@RequestMapping("/registration")
	public String  fixAppointment() {
		return "index";
	}
	
	@PostMapping("/register")
	public String appointmentStore(@ModelAttribute AppointmentModel m) {
		System.out.println("model and attribuets"+m);
		repo.save(m);
		return "redirect:/";
		//return appService.appointForm(m);
	}

}
