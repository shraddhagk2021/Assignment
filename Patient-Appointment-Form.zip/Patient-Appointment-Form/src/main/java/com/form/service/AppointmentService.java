package com.form.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.form.model.AppointmentModel;
import com.form.repository.PatientRepository;

@Service
public class AppointmentService {
	
//	@Autowired
//	PatientRepository  repo;
//	
//	public AppointmentModel appointForm(AppointmentModel model) {
//		return repo.save(model);
//		
//	}

}
