package com.form.model;



import java.sql.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="appointmentform")
public class AppointmentModel {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	@Column(name="name")
	String name;
	@Column(name="age")
	int age;
	//@DateTimeFormat(pattern = "MM/dd/yyyy")
	@Column(name="DOB")
	Date DOB;
	@Column(name="bloodGroup")
	String bloodGroup;
	@Column(name="address")
	String address;
	@Column(name="mobile")
	String mobile;
	@Column(name="email")
	String email;
	//@DateTimeFormat(pattern = "MM/dd/yyyy")
	@Column(name="dateOfAppointment")
	Date dateOfAppointment;
	public AppointmentModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AppointmentModel(int id, String name, int age, Date dOB, String bloodGroup, String address, String mobile,
			String email, Date dateOfAppointment) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		DOB = dOB;
		this.bloodGroup = bloodGroup;
		this.address = address;
		this.mobile = mobile;
		this.email = email;
		this.dateOfAppointment = dateOfAppointment;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDateOfAppointment() {
		return dateOfAppointment;
	}
	public void setDateOfAppointment(Date dateOfAppointment) {
		this.dateOfAppointment = dateOfAppointment;
	}
	@Override
	public String toString() {
		return "AppointmentModel [id=" + id + ", name=" + name + ", age=" + age + ", DOB=" + DOB + ", bloodGroup="
				+ bloodGroup + ", address=" + address + ", mobile=" + mobile + ", email=" + email
				+ ", dateOfAppointment=" + dateOfAppointment + "]";
	}
	
	
	
}
