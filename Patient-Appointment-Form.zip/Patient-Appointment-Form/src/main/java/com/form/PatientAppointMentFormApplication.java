package com.form;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientAppointMentFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientAppointMentFormApplication.class, args);
		System.out.println("Doctor appointment form using mvc.....");
	}

}
